# Bhuvaneshwari Thammanaboina — PM Portfolio

> Live portfolio site for Bhuvaneshwari Thammanaboina, Associate Product Manager.  
> Deployed via GitHub Pages — auto-publishes on every push to `main`.

---

## 🚀 How to Publish (Step-by-Step)

### Step 1 — Create a GitHub Account
If you don't have one: [github.com/signup](https://github.com/signup)

---

### Step 2 — Create a New Repository

1. Go to [github.com/new](https://github.com/new)
2. Set **Repository name** to:
   ```
   portfolio
   ```
   *(or your GitHub username — see Step 5 tip below)*
3. Set visibility to **Public**
4. Leave everything else unchecked
5. Click **Create repository**

---

### Step 3 — Upload Your Files

In your new repository, click **"uploading an existing file"** (shown on the empty repo page), then drag and drop these two files:

```
index.html                          ← rename your resume HTML to this
.github/workflows/deploy.yml        ← the auto-deploy workflow
```

> **Important:** rename `Bhuvaneshwari_Thammanaboina_PM_Resume.html` → `index.html` before uploading so GitHub Pages serves it as the homepage.

Click **Commit changes**.

---

### Step 4 — Enable GitHub Pages

1. In your repo, go to **Settings** → **Pages** (left sidebar)
2. Under **Build and deployment**, set Source to:
   - **GitHub Actions**
3. Click **Save**

The workflow will trigger automatically. After ~60 seconds, your site is live!

---

### Step 5 — Your Live URL

Your portfolio will be live at:

```
https://<your-github-username>.github.io/portfolio/
```

**Pro tip:** If you name the repo `<your-github-username>.github.io` instead of `portfolio`, your URL becomes cleaner:
```
https://<your-github-username>.github.io
```

---

### Step 6 — Enable the Download Button (Optional)

The **Download Resume** button on your site already works — it downloads the current page as an HTML file. If you want it to download a PDF instead:

1. Export your resume as a PDF (print → Save as PDF)
2. Name it `Bhuvaneshwari_Thammanaboina_PM_Resume.pdf`
3. Upload it to the repo root
4. In `index.html`, find the `downloadResume` function and replace with:
   ```html
   <a class="clink" href="Bhuvaneshwari_Thammanaboina_PM_Resume.pdf" download>
   ```

---

## 📁 Repository Structure

```
portfolio/
├── index.html                              ← your entire portfolio (single file)
├── .github/
│   └── workflows/
│       └── deploy.yml                      ← auto-deploy on push
└── README.md                               ← this file
```

---

## ✏️ Making Updates

Any time you update your portfolio:

1. Edit `index.html` locally (or directly on GitHub via the pencil ✏️ icon)
2. Commit to `main`
3. GitHub Actions redeploys automatically in ~60 seconds

No build tools, no npm, no config — it's a single HTML file.

---

## 🔗 Share Your Portfolio

Once live, share this link on:
- Your **LinkedIn** headline or About section
- Your **email signature**
- Your **resume PDF** as a QR code or short link

Use [bit.ly](https://bit.ly) or [dub.co](https://dub.co) to shorten the URL if needed.

---

*Built with HTML · CSS · Vanilla JS — no frameworks, no dependencies.*
